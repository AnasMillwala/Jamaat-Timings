import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { PublicMasjidList } from './components/public/PublicMasjidList';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AdminLoginModal } from './components/admin/AdminLoginModal';
import { QaTestSuiteModal } from './components/qa/QaTestSuiteModal';
import { MobileGuideModal } from './components/docs/MobileGuideModal';
import {
  Smartphone,
  FileText,
  CheckCircle,
  Lock,
  Download,
} from 'lucide-react';

function AppContent() {
  const { user, isAdmin, loading: authLoading } = useAuth();
  const [currentView, setCurrentView] = useState<'public' | 'admin'>('public');
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isQaModalOpen, setIsQaModalOpen] = useState(false);
  const [isGuideModalOpen, setIsGuideModalOpen] = useState(false);

  // Check URL hash or parameters on mount
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash.toLowerCase();
      if (hash.includes('admin')) {
        setCurrentView('admin');
      } else {
        setCurrentView('public');
      }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);

    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  const handleSelectAdmin = () => {
    setCurrentView('admin');
    window.location.hash = 'admin';
    if (!isAdmin) {
      setIsLoginModalOpen(true);
    }
  };

  const handleSelectPublic = () => {
    setCurrentView('public');
    window.location.hash = '';
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans text-gray-900 selection:bg-gray-200">
      {/* Top Application Mode Switcher & Tools Bar */}
      <nav className="bg-gray-950 text-white border-b border-gray-800 text-xs px-3 sm:px-6 py-2 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          {/* View Switcher Pill */}
          <div className="flex items-center space-x-1 bg-gray-900 p-0.5 rounded-lg border border-gray-800">
            <button
              type="button"
              onClick={handleSelectPublic}
              className={`px-3 py-1.5 rounded-md font-semibold text-xs flex items-center space-x-1.5 transition-all ${
                currentView === 'public'
                  ? 'bg-white text-gray-950 shadow-xs'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Public App (iOS &amp; Android)</span>
            </button>

            <button
              type="button"
              onClick={handleSelectAdmin}
              className={`px-3 py-1.5 rounded-md font-semibold text-xs flex items-center space-x-1.5 transition-all ${
                currentView === 'admin'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Private Admin App</span>
              {isAdmin && (
                <span className="w-2 h-2 rounded-full bg-emerald-300 ml-1"></span>
              )}
            </button>
          </div>

          {/* Quick Tools & Documentation */}
          <div className="flex items-center space-x-2">
            <a
              href="/jamaat-timings-source.zip"
              download="jamaat-timings-source.zip"
              className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-600 text-white rounded-md text-[11px] font-semibold transition-colors flex items-center space-x-1 shadow-xs"
              title="Download Source Code ZIP directly to your phone"
            >
              <Download className="w-3 h-3 text-emerald-200" />
              <span>Download ZIP</span>
            </a>

            <button
              type="button"
              onClick={() => setIsQaModalOpen(true)}
              className="px-2.5 py-1 bg-gray-800/80 hover:bg-gray-800 text-gray-300 hover:text-white rounded-md text-[11px] font-medium transition-colors flex items-center space-x-1"
              title="Run 13 QA Test Scenarios"
            >
              <CheckCircle className="w-3 h-3 text-emerald-400" />
              <span className="hidden sm:inline">QA Test Suite</span>
              <span className="sm:hidden">QA</span>
            </button>

            <button
              type="button"
              onClick={() => setIsGuideModalOpen(true)}
              className="px-2.5 py-1 bg-gray-800/80 hover:bg-gray-800 text-gray-300 hover:text-white rounded-md text-[11px] font-medium transition-colors flex items-center space-x-1"
              title="Mobile Build & Packaging Guide"
            >
              <FileText className="w-3 h-3 text-blue-400" />
              <span className="hidden sm:inline">Mobile Build Guide</span>
              <span className="sm:hidden">Build</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Main View Render */}
      <div className="flex-1 flex flex-col">
        {currentView === 'public' ? (
          <PublicMasjidList onOpenAdminPrompt={handleSelectAdmin} />
        ) : (
          <>
            {isAdmin ? (
              <AdminDashboard onBackToPublic={handleSelectPublic} />
            ) : (
              <div className="flex-1 flex items-center justify-center p-6 bg-gray-100">
                <div className="bg-white rounded-2xl max-w-md w-full p-8 text-center shadow-lg border border-gray-200">
                  <div className="w-12 h-12 rounded-xl bg-gray-900 text-white flex items-center justify-center mx-auto mb-4">
                    <Lock className="w-6 h-6" />
                  </div>
                  <h2 className="text-lg font-bold text-gray-900 mb-2">
                    Private Administrator App
                  </h2>
                  <p className="text-xs text-gray-600 mb-6 leading-relaxed">
                    This portal is restricted exclusively to the designated owner.
                    Please log in with your authorized administrator credentials to manage Masjids and update Jamaat timings.
                  </p>
                  <div className="space-y-3">
                    <button
                      type="button"
                      onClick={() => setIsLoginModalOpen(true)}
                      className="w-full py-3 px-4 bg-gray-900 hover:bg-black text-white text-xs font-bold rounded-xl shadow-md transition-all active:scale-98"
                    >
                      Log In to Administrator Console
                    </button>
                    <button
                      type="button"
                      onClick={handleSelectPublic}
                      className="w-full py-2.5 px-4 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-medium rounded-xl transition-colors"
                    >
                      Return to Public Jamaat Timings
                    </button>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Admin Login Modal */}
      <AdminLoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
      />

      {/* QA Test Suite Modal */}
      <QaTestSuiteModal
        isOpen={isQaModalOpen}
        onClose={() => setIsQaModalOpen(false)}
      />

      {/* Mobile Build & APK Guide Modal */}
      <MobileGuideModal
        isOpen={isGuideModalOpen}
        onClose={() => setIsGuideModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
