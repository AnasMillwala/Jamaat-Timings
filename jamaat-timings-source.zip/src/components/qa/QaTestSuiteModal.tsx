import React, { useState, useEffect } from 'react';
import { CheckCircle2, XCircle, Play, ShieldAlert, X, RefreshCw, Smartphone, Cloud, Cpu } from 'lucide-react';
import { runAutomatedTestSuite, TestResult } from '../../tests/automatedTests';

interface QaTestSuiteModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const QaTestSuiteModal: React.FC<QaTestSuiteModalProps> = ({ isOpen, onClose }) => {
  const [results, setResults] = useState<TestResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [hasRun, setHasRun] = useState(false);

  const executeSuite = async () => {
    setIsRunning(true);
    try {
      const suiteResults = await runAutomatedTestSuite();
      setResults(suiteResults);
      setHasRun(true);
    } catch (err) {
      console.error('QA suite execution failed:', err);
    } finally {
      setIsRunning(false);
    }
  };

  useEffect(() => {
    if (isOpen && !hasRun) {
      executeSuite();
    }
  }, [isOpen, hasRun]);

  if (!isOpen) return null;

  const passedCount = results.filter((r) => r.status === 'passed').length;
  const failedCount = results.filter((r) => r.status === 'failed').length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-gray-100 my-8 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-gray-400 hover:text-gray-700 rounded-full hover:bg-gray-100 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gray-900 text-white flex items-center justify-center">
            <ShieldAlert className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <h2 className="text-base font-bold text-gray-900">
              QA Test Suite &amp; Verification Report
            </h2>
            <p className="text-xs text-gray-500">
              13 Validation Scenarios from Section 6
            </p>
          </div>
        </div>

        {/* Summary metrics */}
        <div className="grid grid-cols-3 gap-3 mb-5">
          <div className="bg-gray-50 rounded-xl p-3 border border-gray-200 text-center">
            <span className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider block">
              Total Scenarios
            </span>
            <span className="text-lg font-bold text-gray-900">{results.length || 13}</span>
          </div>
          <div className="bg-emerald-50 rounded-xl p-3 border border-emerald-200 text-center">
            <span className="text-[10px] text-emerald-700 font-semibold uppercase tracking-wider block">
              Passed
            </span>
            <span className="text-lg font-bold text-emerald-800">{passedCount}</span>
          </div>
          <div className="bg-red-50 rounded-xl p-3 border border-red-200 text-center">
            <span className="text-[10px] text-red-700 font-semibold uppercase tracking-wider block">
              Failed
            </span>
            <span className="text-lg font-bold text-red-800">{failedCount}</span>
          </div>
        </div>

        {/* Run / Re-run Action */}
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs text-gray-500 font-medium">
            Category Legend: <Cpu className="w-3 h-3 inline mx-0.5" /> Automated &bull;{' '}
            <Cloud className="w-3 h-3 inline mx-0.5" /> Cloud &bull;{' '}
            <Smartphone className="w-3 h-3 inline mx-0.5" /> Device UX
          </span>
          <button
            type="button"
            onClick={executeSuite}
            disabled={isRunning}
            className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-gray-900 text-white text-xs font-semibold rounded-lg hover:bg-black transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRunning ? 'animate-spin' : ''}`} />
            <span>{isRunning ? 'Running Tests...' : 'Re-run Suite'}</span>
          </button>
        </div>

        {/* Test Cases Results List */}
        <div className="max-h-96 overflow-y-auto space-y-2.5 pr-1 divide-y divide-gray-100">
          {results.map((res) => (
            <div key={res.id} className="pt-2 first:pt-0">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start space-x-2">
                  {res.status === 'passed' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  )}
                  <div>
                    <div className="text-xs font-bold text-gray-900">
                      {res.id}. {res.scenario}
                    </div>
                    <p className="text-[11px] text-gray-600 mt-0.5 leading-relaxed">
                      {res.executionDetails}
                    </p>
                  </div>
                </div>

                <div className="shrink-0 text-right">
                  <span
                    className={`inline-block px-2 py-0.5 text-[10px] font-bold rounded-full uppercase ${
                      res.status === 'passed'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-red-100 text-red-800'
                    }`}
                  >
                    {res.status}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-5 pt-4 border-t border-gray-100 flex items-center justify-between">
          <p className="text-[11px] text-gray-400">
            Automated test runner executed against live Firestore rules &amp; schemas.
          </p>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs font-semibold rounded-xl transition-colors"
          >
            Close Report
          </button>
        </div>
      </div>
    </div>
  );
};
