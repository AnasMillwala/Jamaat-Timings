import React, { useState, useEffect, useRef } from 'react';
import { Clock, X, Check } from 'lucide-react';

interface TimePickerInputProps {
  label: string;
  value: string; // e.g. "05:30 AM" or ""
  onChange: (newValue: string) => void;
  required?: boolean;
}

export const TimePickerInput: React.FC<TimePickerInputProps> = ({
  label,
  value,
  onChange,
  required = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Parse existing value "HH:MM AM/PM" or fallback
  const parseTime = (val: string) => {
    const match = val.trim().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
    if (match) {
      let hh = parseInt(match[1], 10);
      if (hh < 1) hh = 1;
      if (hh > 12) hh = 12;
      return {
        hour: hh.toString().padStart(2, '0'),
        minute: match[2],
        period: match[3].toUpperCase() as 'AM' | 'PM',
      };
    }
    return { hour: '05', minute: '00', period: 'AM' as 'AM' | 'PM' };
  };

  const parsed = parseTime(value);
  const [selectedHour, setSelectedHour] = useState(parsed.hour);
  const [selectedMinute, setSelectedMinute] = useState(parsed.minute);
  const [selectedPeriod, setSelectedPeriod] = useState<'AM' | 'PM'>(parsed.period);

  useEffect(() => {
    if (value) {
      const p = parseTime(value);
      setSelectedHour(p.hour);
      setSelectedMinute(p.minute);
      setSelectedPeriod(p.period);
    }
  }, [value]);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isOpen]);

  const applyTime = (h = selectedHour, m = selectedMinute, p = selectedPeriod) => {
    const formatted = `${h}:${m} ${p}`;
    onChange(formatted);
    setIsOpen(false);
  };

  const clearTime = () => {
    onChange('');
    setIsOpen(false);
  };

  const hours = Array.from({ length: 12 }, (_, i) => (i + 1).toString().padStart(2, '0'));
  const minutes = ['00', '05', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55'];

  return (
    <div className="relative" ref={dropdownRef}>
      <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
        {label} {required && <span className="text-red-500">*</span>}
      </label>

      <div className="flex items-center space-x-1.5">
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className={`flex-1 flex items-center justify-between px-3 py-2 bg-white border rounded-lg text-sm transition-all focus:outline-none focus:ring-2 focus:ring-gray-900 ${
            value ? 'border-gray-300 text-gray-900 font-medium' : 'border-dashed border-gray-300 text-gray-400'
          }`}
          aria-expanded={isOpen}
          aria-haspopup="dialog"
        >
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4 text-gray-400" />
            <span>{value || 'Not set (Blank)'}</span>
          </div>
          <span className="text-xs text-gray-400">Edit</span>
        </button>

        {value && (
          <button
            type="button"
            onClick={clearTime}
            title="Clear timing (leave blank)"
            className="p-2 text-gray-400 hover:text-red-600 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Dropdown / Popover Dialog for 12-hour AM/PM picker */}
      {isOpen && (
        <div className="absolute z-50 mt-1 left-0 right-0 sm:w-72 bg-white rounded-xl shadow-xl border border-gray-200 p-4 animate-in fade-in zoom-in-95 duration-100">
          <div className="text-xs font-bold text-gray-600 mb-3 uppercase tracking-wider">
            Select {label} Jamaat Time
          </div>

          <div className="grid grid-cols-3 gap-2 mb-4">
            {/* Hour Picker */}
            <div>
              <span className="block text-[11px] text-gray-500 mb-1 text-center font-medium">Hour</span>
              <select
                value={selectedHour}
                onChange={(e) => setSelectedHour(e.target.value)}
                className="w-full bg-gray-50 border border-gray-300 rounded-lg py-2 px-2 text-center text-sm font-semibold text-gray-800 focus:bg-white focus:ring-2 focus:ring-gray-900 focus:outline-none"
              >
                {hours.map((h) => (
                  <option key={h} value={h}>
                    {h}
                  </option>
                ))}
              </select>
            </div>

            {/* Minute Picker */}
            <div>
              <span className="block text-[11px] text-gray-500 mb-1 text-center font-medium">Min</span>
              <select
                value={selectedMinute}
                onChange={(e) => setSelectedMinute(e.target.value)}
                className="w-full bg-gray-50 border border-gray-300 rounded-lg py-2 px-2 text-center text-sm font-semibold text-gray-800 focus:bg-white focus:ring-2 focus:ring-gray-900 focus:outline-none"
              >
                {minutes.map((m) => (
                  <option key={m} value={m}>
                    :{m}
                  </option>
                ))}
              </select>
            </div>

            {/* AM / PM Toggle */}
            <div>
              <span className="block text-[11px] text-gray-500 mb-1 text-center font-medium">Period</span>
              <div className="flex bg-gray-100 p-0.5 rounded-lg border border-gray-300">
                <button
                  type="button"
                  onClick={() => setSelectedPeriod('AM')}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-md transition-all ${
                    selectedPeriod === 'AM'
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-500 hover:text-gray-900'
                  }`}
                >
                  AM
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedPeriod('PM')}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-md transition-all ${
                    selectedPeriod === 'PM'
                      ? 'bg-white text-gray-900 shadow-sm'
                      : 'text-gray-500 hover:text-gray-900'
                  }`}
                >
                  PM
                </button>
              </div>
            </div>
          </div>

          {/* Quick Presets row */}
          <div className="mb-4">
            <span className="block text-[10px] text-gray-400 mb-1 uppercase tracking-wider font-semibold">
              Quick Timings
            </span>
            <div className="flex flex-wrap gap-1.5">
              {['05:30 AM', '01:30 PM', '05:15 PM', '06:45 PM', '08:30 PM'].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => {
                    const p = parseTime(preset);
                    setSelectedHour(p.hour);
                    setSelectedMinute(p.minute);
                    setSelectedPeriod(p.period);
                    applyTime(p.hour, p.minute, p.period);
                  }}
                  className="text-[11px] px-2 py-1 bg-gray-100 hover:bg-gray-200 rounded text-gray-700 font-medium"
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-between pt-2 border-t border-gray-100">
            <button
              type="button"
              onClick={clearTime}
              className="text-xs text-red-600 hover:text-red-700 font-medium px-2 py-1 rounded"
            >
              Leave Blank
            </button>
            <div className="flex space-x-2">
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="text-xs text-gray-500 hover:text-gray-800 px-3 py-1.5 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => applyTime()}
                className="text-xs bg-gray-900 text-white font-semibold px-3 py-1.5 rounded-lg flex items-center space-x-1 hover:bg-black shadow-sm"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Save</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
