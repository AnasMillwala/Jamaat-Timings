import React, { useState, useEffect } from 'react';
import {
  Plus,
  Search,
  Edit3,
  Trash2,
  LogOut,
  Building2,
  Clock,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import { MasjidFormData, MasjidRecord, TIMING_KEYS } from '../../types/masjid';
import {
  subscribeMasjids,
  addMasjid,
  updateMasjid,
  deleteMasjid,
  checkAndSeedInitialMasjids,
} from '../../services/masjidService';
import { useAuth } from '../../context/AuthContext';
import { AdminMasjidModal } from './AdminMasjidModal';
import { DeleteConfirmationModal } from './DeleteConfirmationModal';

interface AdminDashboardProps {
  onBackToPublic?: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onBackToPublic }) => {
  const { user, isAdmin, logout } = useAuth();
  const [masjids, setMasjids] = useState<MasjidRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Modal states
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingMasjid, setEditingMasjid] = useState<MasjidRecord | null>(null);
  const [deletingMasjid, setDeletingMasjid] = useState<MasjidRecord | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);

  useEffect(() => {
    setLoading(true);
    const unsubscribe = subscribeMasjids(
      (data) => {
        setMasjids(data);
        setLoading(false);
        setError(null);
      },
      (err) => {
        console.error('Subscription error in admin:', err);
        setError('Error synchronizing database: ' + err.message);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  const handleOpenAdd = () => {
    setEditingMasjid(null);
    setIsFormModalOpen(true);
  };

  const handleOpenEdit = (masjid: MasjidRecord) => {
    setEditingMasjid(masjid);
    setIsFormModalOpen(true);
  };

  const handleSaveMasjid = async (data: MasjidFormData, id?: string) => {
    if (id) {
      await updateMasjid(id, data);
      showToast(`Updated "${data.name}" successfully!`);
    } else {
      await addMasjid(data);
      showToast(`Added "${data.name}" to directory!`);
    }
  };

  const handleConfirmDelete = async (id: string) => {
    setIsDeleting(true);
    try {
      const name = deletingMasjid?.name || 'Masjid';
      await deleteMasjid(id);
      setDeletingMasjid(null);
      showToast(`Deleted "${name}" successfully.`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to delete';
      showToast(msg, 'error');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleSeedDefaults = async () => {
    setIsSeeding(true);
    try {
      const seeded = await checkAndSeedInitialMasjids();
      if (seeded) {
        showToast('Sample Masjids seeded successfully!');
      } else {
        showToast('Database already contains Masjids.', 'error');
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Seeding failed';
      showToast(msg, 'error');
    } finally {
      setIsSeeding(false);
    }
  };

  // Filtered alphabetically
  const filteredMasjids = masjids.filter((m) =>
    m.name.toLowerCase().includes(searchQuery.toLowerCase().trim())
  );

  return (
    <div className="min-h-screen bg-gray-100 text-gray-900 flex flex-col font-sans pb-24">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 animate-in slide-in-from-top-4 duration-200">
          <div
            className={`px-4 py-2.5 rounded-xl shadow-lg border flex items-center space-x-2 text-xs font-semibold ${
              toastMessage.type === 'success'
                ? 'bg-emerald-900 text-white border-emerald-800'
                : 'bg-red-900 text-white border-red-800'
            }`}
          >
            {toastMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-300" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-300" />
            )}
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}

      {/* Admin App Bar */}
      <header className="bg-gray-900 text-white sticky top-0 z-30 shadow-md">
        <div className="max-w-4xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <h1 className="text-sm font-bold tracking-tight">Admin Console</h1>
                <p className="text-[11px] text-gray-400 truncate max-w-[180px] sm:max-w-none">
                  {user?.email || 'Authorized Administrator'}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              {onBackToPublic && (
                <button
                  type="button"
                  onClick={onBackToPublic}
                  className="px-2.5 py-1.5 text-xs text-gray-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-lg transition-colors"
                >
                  View Public
                </button>
              )}
              <button
                type="button"
                onClick={() => logout()}
                className="p-1.5 text-gray-400 hover:text-red-400 rounded-lg hover:bg-white/5 transition-colors"
                title="Log out of Admin app"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Search bar inside admin app header */}
        <div className="max-w-4xl mx-auto px-4 pb-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Quick search Masjid to edit..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-800/90 text-white border border-gray-700 rounded-xl pl-9 pr-4 py-2 text-xs placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-gray-400 hover:text-white px-1"
              >
                ✕
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 py-4">
        {/* Statistics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mb-4">
          <div className="bg-white p-3 rounded-xl border border-gray-200 shadow-2xs">
            <span className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider block">
              Total Masjids
            </span>
            <span className="text-xl font-bold text-gray-900">{masjids.length}</span>
          </div>

          <div className="bg-white p-3 rounded-xl border border-gray-200 shadow-2xs">
            <span className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider block">
              Active Sync
            </span>
            <div className="flex items-center space-x-1.5 mt-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-xs font-semibold text-emerald-700">Real-time</span>
            </div>
          </div>

          <div className="col-span-2 sm:col-span-1 bg-white p-3 rounded-xl border border-gray-200 shadow-2xs flex items-center justify-between">
            <div>
              <span className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider block">
                Database
              </span>
              <span className="text-xs font-semibold text-gray-700">Cloud Firestore</span>
            </div>
            {masjids.length === 0 && (
              <button
                type="button"
                onClick={handleSeedDefaults}
                disabled={isSeeding}
                className="text-[11px] bg-gray-900 text-white font-medium px-2.5 py-1 rounded-md hover:bg-black transition-colors flex items-center space-x-1 disabled:opacity-50"
              >
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>Seed Sample Data</span>
              </button>
            )}
          </div>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="bg-white rounded-xl border border-gray-200 p-8 text-center shadow-2xs">
            <RefreshCw className="w-6 h-6 text-gray-400 animate-spin mx-auto mb-2" />
            <p className="text-xs text-gray-500 font-medium">Fetching Masjid directory...</p>
          </div>
        )}

        {/* Error Alert */}
        {!loading && error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-xs text-red-800 mb-4 flex items-start space-x-2">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
            <div>
              <strong>Sync Error:</strong> {error}
            </div>
          </div>
        )}

        {/* Empty state */}
        {!loading && !error && filteredMasjids.length === 0 && (
          <div className="bg-white rounded-2xl border border-gray-200 p-8 text-center shadow-2xs">
            <Building2 className="w-10 h-10 text-gray-400 mx-auto mb-3" />
            <h3 className="text-sm font-bold text-gray-900">
              {searchQuery ? 'No Masjids matched search' : 'No Masjids added yet'}
            </h3>
            <p className="text-xs text-gray-500 mt-1 max-w-xs mx-auto">
              {searchQuery
                ? 'Try a different search term.'
                : 'Tap "Add Masjid" below or "Seed Sample Data" above to begin managing timings.'}
            </p>
            {!searchQuery && (
              <button
                type="button"
                onClick={handleOpenAdd}
                className="mt-4 inline-flex items-center space-x-1.5 px-4 py-2 bg-gray-900 hover:bg-black text-white rounded-xl text-xs font-semibold shadow-sm transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>Add First Masjid</span>
              </button>
            )}
          </div>
        )}

        {/* Masjid Cards List - Alphabetical */}
        {!loading && !error && filteredMasjids.length > 0 && (
          <div className="space-y-3">
            <div className="text-xs font-bold text-gray-600 uppercase tracking-wider flex items-center justify-between px-1">
              <span>Masjids Alphabetical Directory ({filteredMasjids.length})</span>
              <span className="text-[11px] text-gray-400 font-normal">Tap edit to update timings</span>
            </div>

            {filteredMasjids.map((masjid) => (
              <div
                key={masjid.id}
                className="bg-white rounded-2xl border border-gray-200 p-4 shadow-2xs hover:shadow-xs transition-shadow"
              >
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-bold text-gray-900 truncate" title={masjid.name}>
                      {masjid.name}
                    </h3>
                    <p className="text-[10px] text-gray-400 mt-0.5">
                      Last updated:{' '}
                      {masjid.updatedAt
                        ? new Date(masjid.updatedAt).toLocaleDateString([], {
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                          })
                        : 'Initial record'}
                    </p>
                  </div>

                  {/* Actions (One-handed thumb friendly targets) */}
                  <div className="flex items-center space-x-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleOpenEdit(masjid)}
                      className="p-2 text-gray-700 hover:text-gray-900 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors active:scale-95"
                      title="Edit timings"
                      aria-label={`Edit ${masjid.name}`}
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeletingMasjid(masjid)}
                      className="p-2 text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 rounded-xl transition-colors active:scale-95"
                      title="Delete Masjid"
                      aria-label={`Delete ${masjid.name}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* 6 Timings Grid in exact order */}
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 pt-2 border-t border-gray-100 text-center">
                  {TIMING_KEYS.map((t) => (
                    <div key={t.key} className="bg-gray-50 rounded-lg p-1.5 border border-gray-150">
                      <span className="text-[10px] font-semibold text-gray-500 uppercase tracking-tight block">
                        {t.label}
                      </span>
                      <span className="text-xs font-bold text-gray-900 font-mono">
                        {masjid[t.key] || '—'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Floating One-Handed Action Bar at bottom */}
      <div className="fixed bottom-0 inset-x-0 bg-white/95 backdrop-blur-md border-t border-gray-200 p-3 z-40 shadow-lg">
        <div className="max-w-4xl mx-auto flex items-center justify-between space-x-3">
          <div className="text-xs text-gray-500 hidden sm:block">
            One-handed Android Management Console
          </div>
          <button
            type="button"
            onClick={handleOpenAdd}
            className="flex-1 sm:flex-none sm:px-6 py-3 bg-gray-900 hover:bg-black text-white text-sm font-bold rounded-xl flex items-center justify-center space-x-2 shadow-md active:scale-98 transition-all"
          >
            <Plus className="w-5 h-5 text-emerald-400" />
            <span>Add Masjid</span>
          </button>
        </div>
      </div>

      {/* Add / Edit Form Modal */}
      <AdminMasjidModal
        isOpen={isFormModalOpen}
        onClose={() => {
          setIsFormModalOpen(false);
          setEditingMasjid(null);
        }}
        onSave={handleSaveMasjid}
        masjidToEdit={editingMasjid}
        existingMasjids={masjids}
      />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmationModal
        isOpen={Boolean(deletingMasjid)}
        masjid={deletingMasjid}
        onClose={() => setDeletingMasjid(null)}
        onConfirm={handleConfirmDelete}
        isDeleting={isDeleting}
      />
    </div>
  );
};
