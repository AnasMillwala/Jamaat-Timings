import React, { useState, useEffect } from 'react';
import { X, Save, AlertTriangle, AlertCircle, Building2, Check } from 'lucide-react';
import { MasjidFormData, MasjidRecord, TIMING_KEYS } from '../../types/masjid';
import { TimePickerInput } from '../common/TimePickerInput';

interface AdminMasjidModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: MasjidFormData, id?: string) => Promise<void>;
  masjidToEdit?: MasjidRecord | null;
  existingMasjids: MasjidRecord[];
}

export const AdminMasjidModal: React.FC<AdminMasjidModalProps> = ({
  isOpen,
  onClose,
  onSave,
  masjidToEdit,
  existingMasjids,
}) => {
  const [formData, setFormData] = useState<MasjidFormData>({
    name: '',
    fajr: '',
    zuhr: '',
    asr: '',
    magrib: '',
    isha: '',
    jumua: '',
  });

  const [initialData, setInitialData] = useState<MasjidFormData>({
    name: '',
    fajr: '',
    zuhr: '',
    asr: '',
    magrib: '',
    isha: '',
    jumua: '',
  });

  const [error, setError] = useState<string | null>(null);
  const [duplicateWarning, setDuplicateWarning] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [confirmDiscard, setConfirmDiscard] = useState(false);

  useEffect(() => {
    if (masjidToEdit) {
      const data: MasjidFormData = {
        name: masjidToEdit.name,
        fajr: masjidToEdit.fajr || '',
        zuhr: masjidToEdit.zuhr || '',
        asr: masjidToEdit.asr || '',
        magrib: masjidToEdit.magrib || '',
        isha: masjidToEdit.isha || '',
        jumua: masjidToEdit.jumua || '',
      };
      setFormData(data);
      setInitialData(data);
    } else {
      const blank: MasjidFormData = {
        name: '',
        fajr: '',
        zuhr: '',
        asr: '',
        magrib: '',
        isha: '',
        jumua: '',
      };
      setFormData(blank);
      setInitialData(blank);
    }
    setError(null);
    setDuplicateWarning(null);
    setConfirmDiscard(false);
  }, [masjidToEdit, isOpen]);

  // Check for duplicate names
  useEffect(() => {
    const trimmed = formData.name.trim().toLowerCase();
    if (!trimmed) {
      setDuplicateWarning(null);
      return;
    }

    const duplicate = existingMasjids.find((m) => {
      if (masjidToEdit && m.id === masjidToEdit.id) return false;
      return m.name.trim().toLowerCase() === trimmed;
    });

    if (duplicate) {
      setDuplicateWarning(
        `Notice: A Masjid named "${duplicate.name}" already exists in the database. Please verify to avoid confusion.`
      );
    } else {
      setDuplicateWarning(null);
    }
  }, [formData.name, existingMasjids, masjidToEdit]);

  if (!isOpen) return null;

  // Determine if form is dirty
  const isDirty = JSON.stringify(formData) !== JSON.stringify(initialData);

  const handleAttemptClose = () => {
    if (isDirty && !confirmDiscard) {
      setConfirmDiscard(true);
      return;
    }
    onClose();
  };

  const handleTimingChange = (field: keyof MasjidFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const trimmedName = formData.name.trim();
    if (!trimmedName) {
      setError('Masjid name is required.');
      return;
    }

    // Validate timing formats if provided
    for (const t of TIMING_KEYS) {
      const val = formData[t.key].trim();
      if (val && !/^\d{1,2}:\d{2}\s*(AM|PM)$/i.test(val)) {
        setError(`Invalid time format for ${t.label}. Please use 12-hour format e.g. "05:30 AM" or leave blank.`);
        return;
      }
    }

    setIsSubmitting(true);
    try {
      await onSave(formData, masjidToEdit ? masjidToEdit.id : undefined);
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to save Masjid. Check permissions.';
      setError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-gray-100 my-8 relative">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-gray-100 mb-5">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gray-900 text-white flex items-center justify-center">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-gray-900 leading-tight">
                {masjidToEdit ? 'Edit Masjid & Timings' : 'Add New Masjid'}
              </h2>
              <p className="text-xs text-gray-500">
                {masjidToEdit ? 'Update details and prayer schedule' : 'Register a new Masjid in the directory'}
              </p>
            </div>
          </div>
          <button
            onClick={handleAttemptClose}
            className="p-1.5 text-gray-400 hover:text-gray-700 rounded-full hover:bg-gray-100 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Unsaved changes confirmation warning */}
        {confirmDiscard && (
          <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900">
            <p className="font-semibold mb-2">You have unsaved changes. Discard them?</p>
            <div className="flex space-x-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-md font-medium"
              >
                Discard &amp; Exit
              </button>
              <button
                type="button"
                onClick={() => setConfirmDiscard(false)}
                className="px-3 py-1 bg-white border border-amber-300 text-amber-800 rounded-md font-medium"
              >
                Continue Editing
              </button>
            </div>
          </div>
        )}

        {/* Error notice */}
        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-start space-x-2">
            <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {/* Duplicate warning */}
        {duplicateWarning && (
          <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800 flex items-start space-x-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <span>{duplicateWarning}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Masjid Name */}
          <div>
            <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
              Masjid Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              placeholder="e.g. Central Jamia Masjid"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full bg-white border border-gray-300 rounded-lg px-3.5 py-2.5 text-sm font-medium text-gray-900 focus:ring-2 focus:ring-gray-900 focus:outline-none"
              required
            />
            <p className="text-[11px] text-gray-500 mt-1">
              Masjids will be ordered alphabetically by this name.
            </p>
          </div>

          {/* Section: 6 Timings in exact required order */}
          <div className="pt-2">
            <div className="text-xs font-bold text-gray-900 uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>Jamaat Congregation Timings (12-Hour AM/PM)</span>
              <span className="text-[10px] text-gray-500 font-normal">Leave blank if pending</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-gray-50 p-3 rounded-xl border border-gray-200">
              {/* 1. Fajr */}
              <TimePickerInput
                label="1. Fajr Jamaat"
                value={formData.fajr}
                onChange={(val) => handleTimingChange('fajr', val)}
              />

              {/* 2. Zuhr */}
              <TimePickerInput
                label="2. Zuhr Jamaat"
                value={formData.zuhr}
                onChange={(val) => handleTimingChange('zuhr', val)}
              />

              {/* 3. Asr */}
              <TimePickerInput
                label="3. Asr Jamaat"
                value={formData.asr}
                onChange={(val) => handleTimingChange('asr', val)}
              />

              {/* 4. Magrib */}
              <TimePickerInput
                label="4. Magrib Jamaat"
                value={formData.magrib}
                onChange={(val) => handleTimingChange('magrib', val)}
              />

              {/* 5. Isha */}
              <TimePickerInput
                label="5. Isha Jamaat"
                value={formData.isha}
                onChange={(val) => handleTimingChange('isha', val)}
              />

              {/* 6. Jumua */}
              <TimePickerInput
                label="6. Jumua Jamaat"
                value={formData.jumua}
                onChange={(val) => handleTimingChange('jumua', val)}
              />
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-gray-100">
            <button
              type="button"
              onClick={handleAttemptClose}
              disabled={isSubmitting}
              className="py-2.5 px-4 bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs font-semibold rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="py-2.5 px-5 bg-gray-900 hover:bg-black text-white text-xs font-semibold rounded-xl flex items-center space-x-2 transition-all shadow-sm active:scale-98 disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{isSubmitting ? 'Saving to Database...' : masjidToEdit ? 'Save Changes' : 'Add Masjid'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
