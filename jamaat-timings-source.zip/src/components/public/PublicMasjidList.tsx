import React, { useState, useEffect } from 'react';
import { Search, RefreshCw, AlertCircle, Clock, Building2, CheckCircle2 } from 'lucide-react';
import { MasjidRecord, TIMING_KEYS } from '../../types/masjid';
import { subscribeMasjids } from '../../services/masjidService';

interface PublicMasjidListProps {
  onOpenAdminPrompt?: () => void;
}

export const PublicMasjidList: React.FC<PublicMasjidListProps> = ({ onOpenAdminPrompt }) => {
  const [masjids, setMasjids] = useState<MasjidRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [lastRefreshed, setLastRefreshed] = useState<Date | null>(null);
  const [isManualRefreshing, setIsManualRefreshing] = useState(false);

  useEffect(() => {
    setLoading(true);
    const unsubscribe = subscribeMasjids(
      (data) => {
        setMasjids(data);
        setLastRefreshed(new Date());
        setLoading(false);
        setError(null);
      },
      (err) => {
        console.error('Error fetching masjids:', err);
        setError('Unable to load latest timings. Please check your internet connection.');
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  const handleManualRefresh = () => {
    setIsManualRefreshing(true);
    // Real-time snapshot is already active, but trigger feedback
    setTimeout(() => {
      setLastRefreshed(new Date());
      setIsManualRefreshing(false);
    }, 600);
  };

  // Filter Masjids by search query (keeps alphabetical order)
  const filteredMasjids = masjids.filter((masjid) =>
    masjid.name.toLowerCase().includes(searchQuery.toLowerCase().trim())
  );

  const formatLastRefreshed = (date: Date | null) => {
    if (!date) return 'Waiting for update...';
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 flex flex-col font-sans antialiased">
      {/* App Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-lg bg-gray-900 flex items-center justify-center text-white">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-lg font-bold tracking-tight text-gray-900 leading-none">
                  Jamaat Timings
                </h1>
                <p className="text-xs text-gray-500 mt-1">
                  Daily Congregation Times
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={handleManualRefresh}
                disabled={isManualRefreshing}
                className="inline-flex items-center space-x-1.5 px-3 py-1.5 text-xs font-medium text-gray-700 bg-white hover:bg-gray-100 border border-gray-300 rounded-md transition-colors active:scale-95 disabled:opacity-50"
                title="Refresh timings"
                aria-label="Refresh timings"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isManualRefreshing ? 'animate-spin' : ''}`} />
                <span className="hidden sm:inline">Refresh</span>
              </button>
            </div>
          </div>
        </div>

        {/* Search & Sync Status Bar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 bg-gray-50/70 border-t border-gray-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          {/* Search Bar */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search Masjid name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-gray-200 rounded-lg pl-9 pr-4 py-1.5 text-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-gray-400 hover:text-gray-700 px-1 py-0.5 rounded"
              >
                Clear
              </button>
            )}
          </div>

          {/* Sync status */}
          <div className="flex items-center justify-between sm:justify-end text-xs text-gray-500 space-x-4">
            <span className="flex items-center space-x-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
              <span>Live Database</span>
            </span>
            <span>
              Updated: <strong className="text-gray-700">{formatLastRefreshed(lastRefreshed)}</strong>
            </span>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-2 sm:px-6 lg:px-8 py-4 sm:py-6">
        {/* Important notice badge */}
        <div className="mb-4 bg-white border border-gray-200 rounded-lg p-3 text-xs text-gray-600 flex items-start space-x-2.5 shadow-2xs">
          <Clock className="w-4 h-4 text-gray-600 shrink-0 mt-0.5" />
          <p>
            Times listed below are <strong>Jamaat (Congregation) timings</strong> entered directly by the administration.
            They are not calculated Adhan timings.
          </p>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="bg-white rounded-xl border border-gray-200 p-12 text-center shadow-2xs">
            <RefreshCw className="w-8 h-8 text-gray-400 animate-spin mx-auto mb-3" />
            <h3 className="text-sm font-semibold text-gray-900">Loading Jamaat Timings...</h3>
            <p className="text-xs text-gray-500 mt-1">Connecting to live database</p>
          </div>
        )}

        {/* Error State */}
        {!loading && error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-6 text-center shadow-2xs">
            <AlertCircle className="w-8 h-8 text-red-600 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-red-900">{error}</h3>
            <p className="text-xs text-red-700 mt-1">
              Please verify your network connection and tap refresh.
            </p>
            <button
              onClick={handleManualRefresh}
              className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg text-xs font-semibold hover:bg-red-700 transition-colors"
            >
              Retry Connection
            </button>
          </div>
        )}

        {/* Empty State */}
        {!loading && !error && filteredMasjids.length === 0 && (
          <div className="bg-white rounded-xl border border-gray-200 p-12 text-center shadow-2xs">
            <Building2 className="w-10 h-10 text-gray-400 mx-auto mb-3" />
            <h3 className="text-sm font-semibold text-gray-900">
              {searchQuery ? `No Masjids matching "${searchQuery}"` : 'No Masjids listed yet'}
            </h3>
            <p className="text-xs text-gray-500 mt-1 max-w-sm mx-auto">
              {searchQuery
                ? 'Try searching with a different spelling or clear the search filter.'
                : 'Masjids and their congregation timings will appear here once added by the administrator.'}
            </p>
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="mt-3 text-xs font-semibold text-gray-900 underline hover:text-black"
              >
                Clear search filter
              </button>
            )}
          </div>
        )}

        {/* Masjid Timings Table / List */}
        {!loading && !error && filteredMasjids.length > 0 && (
          <div className="bg-white rounded-xl border border-gray-200 shadow-2xs overflow-hidden">
            {/* Horizontally scrollable table container for narrow mobile screens */}
            <div className="overflow-x-auto scrollbar-thin">
              <table className="w-full text-left border-collapse min-w-[640px]">
                <thead>
                  <tr className="bg-gray-100/80 border-b border-gray-200 text-[11px] font-bold text-gray-700 uppercase tracking-wider sticky top-0">
                    <th scope="col" className="py-3 px-4 font-bold text-gray-900 sticky left-0 bg-gray-100/95 z-10 w-52 sm:w-64 border-r border-gray-200 shadow-xs">
                      Masjid Name
                    </th>
                    {TIMING_KEYS.map((t) => (
                      <th
                        key={t.key}
                        scope="col"
                        className="py-3 px-3 text-center w-24 sm:w-28 border-r border-gray-200 last:border-r-0"
                      >
                        <div>{t.label}</div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 text-sm">
                  {filteredMasjids.map((masjid, index) => (
                    <tr
                      key={masjid.id}
                      className={`hover:bg-gray-50/80 transition-colors ${
                        index % 2 === 0 ? 'bg-white' : 'bg-gray-50/30'
                      }`}
                    >
                      {/* Masjid Name - Sticky on mobile horizontal scroll */}
                      <td className="py-3.5 px-4 font-semibold text-gray-900 sticky left-0 bg-inherit z-10 border-r border-gray-200">
                        <div className="truncate max-w-[190px] sm:max-w-[240px]" title={masjid.name}>
                          {masjid.name}
                        </div>
                      </td>

                      {/* Six Jamaat Timings in exact order: Fajr, Zuhr, Asr, Magrib, Isha, Jumua */}
                      {TIMING_KEYS.map((t) => {
                        const timeValue = masjid[t.key];
                        return (
                          <td
                            key={t.key}
                            className="py-3.5 px-3 text-center border-r border-gray-200 last:border-r-0 whitespace-nowrap"
                          >
                            {timeValue ? (
                              <span className="font-mono text-xs sm:text-sm font-bold text-gray-900">
                                {timeValue}
                              </span>
                            ) : (
                              <span className="text-gray-300 font-mono text-sm" title="Timing not yet updated">
                                —
                              </span>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile swipe hint banner on narrow screens */}
            <div className="sm:hidden px-4 py-2 bg-gray-50 border-t border-gray-100 text-center text-[11px] text-gray-500">
              Swipe table horizontally to view all 6 timings
            </div>

            {/* Total count footer */}
            <div className="px-4 py-3 bg-white border-t border-gray-200 flex items-center justify-between text-xs text-gray-500">
              <span>
                Showing <strong>{filteredMasjids.length}</strong> of <strong>{masjids.length}</strong> listed Masjids (Alphabetical)
              </span>
              <span className="flex items-center space-x-1 text-emerald-700">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Verified Jamaat Schedule</span>
              </span>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-4 mt-8">
        <div className="max-w-7xl mx-auto px-4 text-center text-xs text-gray-500 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            <strong>Jamaat Timings</strong> &bull; Congregation prayer times across Masjids
          </div>
          {onOpenAdminPrompt && (
            <button
              onClick={onOpenAdminPrompt}
              className="text-gray-400 hover:text-gray-700 text-xs transition-colors underline"
            >
              Administrator Access
            </button>
          )}
        </div>
      </footer>
    </div>
  );
};
