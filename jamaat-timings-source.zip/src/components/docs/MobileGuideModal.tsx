import React, { useState } from 'react';
import { Smartphone, Apple, ShieldCheck, Download, Copy, Check, X, Terminal, FileCode } from 'lucide-react';

interface MobileGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MobileGuideModal: React.FC<MobileGuideModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'admin_apk' | 'public_app' | 'firebase'>('admin_apk');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-gray-100 my-8 relative max-h-[90vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-gray-400 hover:text-gray-700 rounded-full hover:bg-gray-100 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3 mb-4 shrink-0">
          <div className="w-10 h-10 rounded-xl bg-gray-900 text-white flex items-center justify-center">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-gray-900">
              Mobile Installation &amp; Build Guide
            </h2>
            <p className="text-xs text-gray-500">
              Private Admin APK (Android) &bull; Public App (iOS &amp; Android)
            </p>
          </div>
        </div>

        {/* Tab selection */}
        <div className="flex bg-gray-100 p-1 rounded-xl mb-4 shrink-0">
          <button
            onClick={() => setActiveTab('admin_apk')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center space-x-1.5 ${
              activeTab === 'admin_apk' ? 'bg-white text-gray-900 shadow-xs' : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Smartphone className="w-4 h-4 text-emerald-600" />
            <span>Admin Private APK</span>
          </button>
          <button
            onClick={() => setActiveTab('public_app')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center space-x-1.5 ${
              activeTab === 'public_app' ? 'bg-white text-gray-900 shadow-xs' : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Apple className="w-4 h-4 text-gray-800" />
            <span>Public App (iOS &amp; Android)</span>
          </button>
          <button
            onClick={() => setActiveTab('firebase')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center space-x-1.5 ${
              activeTab === 'firebase' ? 'bg-white text-gray-900 shadow-xs' : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-amber-600" />
            <span>Security &amp; Auth</span>
          </button>
        </div>

        {/* Scrollable content body */}
        <div className="flex-1 overflow-y-auto space-y-4 text-xs text-gray-700 pr-1">
          {activeTab === 'admin_apk' && (
            <div className="space-y-3">
              {/* Phone Direct Download Banner */}
              <div className="bg-emerald-900 text-white rounded-xl p-4 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="font-bold text-sm text-white flex items-center space-x-1.5">
                    <Download className="w-4 h-4 text-emerald-300" />
                    <span>Download Project ZIP (Direct to Phone)</span>
                  </h4>
                  <p className="text-[11px] text-emerald-150 mt-1 leading-relaxed">
                    Includes all source code, package.json, Capacitor configs, and automated GitHub Actions APK builder.
                  </p>
                </div>
                <a
                  href="/jamaat-timings-source.zip"
                  download="jamaat-timings-source.zip"
                  className="inline-flex items-center justify-center space-x-2 px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-gray-950 font-bold text-xs rounded-xl transition-all shadow-sm active:scale-95 shrink-0"
                >
                  <Download className="w-4 h-4" />
                  <span>Download ZIP (48 KB)</span>
                </a>
              </div>

              {/* No-Computer Cloud Build Info */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-blue-950">
                <strong className="block font-semibold mb-1 text-blue-900">
                  📱 Building APK on an Android Phone (No Computer Needed)
                </strong>
                <p className="text-[11px] leading-relaxed">
                  We have included a pre-configured <strong>GitHub Actions</strong> workflow (<code>.github/workflows/build-apk.yml</code>).
                  You can upload this ZIP to a free GitHub repository directly from your phone browser, and GitHub will automatically compile the APK in the cloud and give you a direct download link!
                </p>
              </div>

              <div className="space-y-2">
                <h4 className="font-bold text-gray-900 uppercase text-[11px] tracking-wider">
                  Step 1: Install Capacitor in the Project
                </h4>
                <div className="bg-gray-900 text-gray-100 p-2.5 rounded-lg font-mono text-[11px] flex items-center justify-between">
                  <code>npm install @capacitor/core @capacitor/cli @capacitor/android</code>
                  <button
                    onClick={() =>
                      copyToClipboard(
                        'npm install @capacitor/core @capacitor/cli @capacitor/android',
                        'c1'
                      )
                    }
                    className="p-1 hover:text-white"
                  >
                    {copiedKey === 'c1' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>

                <h4 className="font-bold text-gray-900 uppercase text-[11px] tracking-wider pt-1">
                  Step 2: Initialize &amp; Build Android Project
                </h4>
                <div className="bg-gray-900 text-gray-100 p-2.5 rounded-lg font-mono text-[11px] flex items-center justify-between">
                  <code>npx cap init &quot;Jamaat Timings Admin&quot; com.jamaattimings.admin --web-dir dist &amp;&amp; npm run build &amp;&amp; npx cap add android</code>
                  <button
                    onClick={() =>
                      copyToClipboard(
                        'npx cap init "Jamaat Timings Admin" com.jamaattimings.admin --web-dir dist && npm run build && npx cap add android',
                        'c2'
                      )
                    }
                    className="p-1 hover:text-white"
                  >
                    {copiedKey === 'c2' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>

                <h4 className="font-bold text-gray-900 uppercase text-[11px] tracking-wider pt-1">
                  Step 3: Generate the APK File
                </h4>
                <div className="bg-gray-900 text-gray-100 p-2.5 rounded-lg font-mono text-[11px] flex items-center justify-between">
                  <code>cd android &amp;&amp; ./gradlew assembleDebug</code>
                  <button
                    onClick={() => copyToClipboard('cd android && ./gradlew assembleDebug', 'c3')}
                    className="p-1 hover:text-white"
                  >
                    {copiedKey === 'c3' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <p className="text-gray-500">
                  The generated APK will be located at:
                  <br />
                  <code className="bg-gray-100 px-1 py-0.5 rounded text-gray-800">
                    android/app/build/outputs/apk/debug/app-debug.apk
                  </code>
                </p>

                <h4 className="font-bold text-gray-900 uppercase text-[11px] tracking-wider pt-1">
                  Step 4: Install APK on Your Android Device
                </h4>
                <ol className="list-decimal pl-4 space-y-1 text-gray-600">
                  <li>Send the <code>app-debug.apk</code> file to your Android phone via Google Drive, WhatsApp, or USB cable.</li>
                  <li>Tap the APK file on your phone. When prompted &quot;Install unknown apps&quot;, toggle &quot;Allow from this source&quot;.</li>
                  <li>Tap &quot;Install&quot;. The app icon will appear on your home screen and open the dedicated Admin app with full offline and secure authentication capability!</li>
                </ol>
              </div>
            </div>
          )}

          {activeTab === 'public_app' && (
            <div className="space-y-3">
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-blue-900">
                <strong className="block font-semibold mb-1">
                  Distribution for Public Users (No Account Required)
                </strong>
                Public users on iPhone and Android can access the live Jamaat Timings instantaneously without creating accounts or downloading heavy files.
              </div>

              <div>
                <h4 className="font-bold text-gray-900 uppercase text-[11px] tracking-wider mb-1">
                  Option 1: Progressive Web App (Instant Home Screen Icon)
                </h4>
                <div className="space-y-1.5 text-gray-600">
                  <p>
                    <strong>On iPhone (iOS Safari):</strong>
                    <br />
                    1. Open the public URL in Safari.
                    <br />
                    2. Tap the <strong>Share</strong> button (square with arrow up).
                    <br />
                    3. Tap <strong>&ldquo;Add to Home Screen&rdquo;</strong>.
                    <br />
                    The app opens in full-screen standalone mode without any browser URL bars, just like a native iOS app.
                  </p>
                  <p className="pt-2">
                    <strong>On Android (Chrome / Brave / Firefox):</strong>
                    <br />
                    1. Open the public URL.
                    <br />
                    2. Tap the three dots menu &gt; <strong>&ldquo;Install App&rdquo;</strong> or <strong>&ldquo;Add to Home screen&rdquo;</strong>.
                  </p>
                </div>
              </div>

              <div className="pt-2">
                <h4 className="font-bold text-gray-900 uppercase text-[11px] tracking-wider mb-1">
                  Option 2: Native iOS Build (Xcode / App Store / TestFlight)
                </h4>
                <p className="text-gray-600 mb-2">
                  To produce an Apple IPA or publish to the App Store, you need a Mac with Xcode:
                </p>
                <div className="bg-gray-900 text-gray-100 p-2.5 rounded-lg font-mono text-[11px] flex items-center justify-between">
                  <code>npm install @capacitor/ios &amp;&amp; npx cap add ios &amp;&amp; npx cap open ios</code>
                  <button
                    onClick={() =>
                      copyToClipboard(
                        'npm install @capacitor/ios && npx cap add ios && npx cap open ios',
                        'c4'
                      )
                    }
                    className="p-1 hover:text-white"
                  >
                    {copiedKey === 'c4' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <p className="text-gray-500 mt-1">
                  In Xcode, select your Apple Developer Team, click &ldquo;Product &gt; Archive&rdquo;, and upload to TestFlight or the App Store.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'firebase' && (
            <div className="space-y-3">
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-amber-900">
                <strong className="block font-semibold mb-1">
                  Firebase Security &amp; Admin Credentials
                </strong>
                The database is secured with enterprise Firestore Security Rules.
              </div>

              <div className="space-y-2 text-gray-600">
                <p>
                  <strong>Designated Administrator:</strong>
                  <br />
                  <code className="bg-gray-100 px-2 py-0.5 rounded text-gray-900 font-mono">
                    millwala27@gmail.com
                  </code>
                </p>
                <p>
                  <strong>Security Enforcement:</strong>
                  <br />
                  - Public users have read-only access to <code>/masjids</code>.
                  <br />
                  - Write, update, and delete access is strictly rejected by Firestore rules unless authenticated as the designated administrator.
                  <br />
                  - Data is validated: Masjid name required, timing fields constrained to 10 characters, duplicate protection, zero ghost keys allowed.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Modal footer */}
        <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-gray-400">
            All files and configs generated in repository root.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-900 hover:bg-black text-white text-xs font-semibold rounded-xl transition-colors"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
