export interface JamaatTimings {
  fajr: string;   // e.g. "05:30 AM" or ""
  zuhr: string;   // e.g. "01:30 PM" or ""
  asr: string;    // e.g. "05:15 PM" or ""
  magrib: string; // e.g. "06:45 PM" or ""
  isha: string;   // e.g. "08:30 PM" or ""
  jumua: string;  // e.g. "01:45 PM" or ""
}

export interface MasjidRecord extends JamaatTimings {
  id: string;
  name: string;
  createdAt?: string;
  updatedAt?: string;
}

export type TimingKey = keyof JamaatTimings;

export const TIMING_KEYS: { key: TimingKey; label: string; period: 'morning' | 'afternoon' | 'evening' | 'night' }[] = [
  { key: 'fajr', label: 'Fajr', period: 'morning' },
  { key: 'zuhr', label: 'Zuhr', period: 'afternoon' },
  { key: 'asr', label: 'Asr', period: 'afternoon' },
  { key: 'magrib', label: 'Magrib', period: 'evening' },
  { key: 'isha', label: 'Isha', period: 'night' },
  { key: 'jumua', label: 'Jumua', period: 'afternoon' },
];

export interface MasjidFormData {
  name: string;
  fajr: string;
  zuhr: string;
  asr: string;
  magrib: string;
  isha: string;
  jumua: string;
}
