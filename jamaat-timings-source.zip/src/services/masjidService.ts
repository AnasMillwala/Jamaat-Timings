import {
  collection,
  onSnapshot,
  query,
  orderBy,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  getDocs,
  limit,
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../lib/firebaseError';
import { MasjidFormData, MasjidRecord } from '../types/masjid';

const MASJIDS_COLLECTION = 'masjids';

/**
 * Subscribe to real-time updates for all Masjids.
 * Guaranteed alphabetical ordering by Masjid name.
 */
export function subscribeMasjids(
  onData: (masjids: MasjidRecord[]) => void,
  onError: (error: Error) => void
): () => void {
  const masjidsRef = collection(db, MASJIDS_COLLECTION);
  const q = query(masjidsRef, orderBy('name', 'asc'));

  const unsubscribe = onSnapshot(
    q,
    (snapshot) => {
      const records: MasjidRecord[] = snapshot.docs.map((docSnap) => {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          name: typeof data.name === 'string' ? data.name : '',
          fajr: typeof data.fajr === 'string' ? data.fajr : '',
          zuhr: typeof data.zuhr === 'string' ? data.zuhr : '',
          asr: typeof data.asr === 'string' ? data.asr : '',
          magrib: typeof data.magrib === 'string' ? data.magrib : '',
          isha: typeof data.isha === 'string' ? data.isha : '',
          jumua: typeof data.jumua === 'string' ? data.jumua : '',
          createdAt: typeof data.createdAt === 'string' ? data.createdAt : undefined,
          updatedAt: typeof data.updatedAt === 'string' ? data.updatedAt : undefined,
        };
      });

      // Client-side guarantee for strict case-insensitive natural alphabetical ordering
      records.sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }));

      onData(records);
    },
    (err) => {
      console.error('Subscription error in subscribeMasjids:', err);
      try {
        handleFirestoreError(err, OperationType.LIST, MASJIDS_COLLECTION);
      } catch (formattedErr) {
        onError(formattedErr instanceof Error ? formattedErr : new Error(String(err)));
      }
    }
  );

  return unsubscribe;
}

/**
 * Add a new Masjid document
 */
export async function addMasjid(data: MasjidFormData): Promise<string> {
  const trimmedName = data.name.trim();
  if (!trimmedName) {
    throw new Error('Masjid name cannot be empty.');
  }

  const payload = {
    name: trimmedName,
    fajr: data.fajr?.trim() || '',
    zuhr: data.zuhr?.trim() || '',
    asr: data.asr?.trim() || '',
    magrib: data.magrib?.trim() || '',
    isha: data.isha?.trim() || '',
    jumua: data.jumua?.trim() || '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  try {
    const docRef = await addDoc(collection(db, MASJIDS_COLLECTION), payload);
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, MASJIDS_COLLECTION);
  }
}

/**
 * Update an existing Masjid's name or Jamaat timings
 */
export async function updateMasjid(id: string, data: MasjidFormData): Promise<void> {
  const trimmedName = data.name.trim();
  if (!trimmedName) {
    throw new Error('Masjid name cannot be empty.');
  }

  const payload = {
    name: trimmedName,
    fajr: data.fajr?.trim() || '',
    zuhr: data.zuhr?.trim() || '',
    asr: data.asr?.trim() || '',
    magrib: data.magrib?.trim() || '',
    isha: data.isha?.trim() || '',
    jumua: data.jumua?.trim() || '',
    updatedAt: new Date().toISOString(),
  };

  try {
    const docRef = doc(db, MASJIDS_COLLECTION, id);
    await updateDoc(docRef, payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${MASJIDS_COLLECTION}/${id}`);
  }
}

/**
 * Delete a Masjid by document ID
 */
export async function deleteMasjid(id: string): Promise<void> {
  try {
    const docRef = doc(db, MASJIDS_COLLECTION, id);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${MASJIDS_COLLECTION}/${id}`);
  }
}

/**
 * Check if the collection is empty and seed starter Masjids
 */
export async function checkAndSeedInitialMasjids(): Promise<boolean> {
  // Only authenticated administrators are allowed to seed data into Firestore
  if (!auth.currentUser) {
    return false;
  }

  try {
    const q = query(collection(db, MASJIDS_COLLECTION), limit(1));
    const snapshot = await getDocs(q);
    if (!snapshot.empty) {
      return false; // already has data
    }

    const initialMasjids: MasjidFormData[] = [
      {
        name: 'Al-Farooq Masjid',
        fajr: '05:45 AM',
        zuhr: '01:30 PM',
        asr: '05:15 PM',
        magrib: '06:40 PM',
        isha: '08:15 PM',
        jumua: '01:45 PM',
      },
      {
        name: 'Baitul Mukarram Center',
        fajr: '05:30 AM',
        zuhr: '01:15 PM',
        asr: '05:00 PM',
        magrib: '06:40 PM',
        isha: '08:00 PM',
        jumua: '01:30 PM',
      },
      {
        name: 'Central Jamia Masjid',
        fajr: '06:00 AM',
        zuhr: '01:30 PM',
        asr: '05:30 PM',
        magrib: '06:45 PM',
        isha: '08:30 PM',
        jumua: '02:00 PM',
      },
      {
        name: 'Darul Huda Islamic Society',
        fajr: '05:45 AM',
        zuhr: '01:30 PM',
        asr: '05:15 PM',
        magrib: '06:40 PM',
        isha: '08:15 PM',
        jumua: '01:45 PM',
      },
      {
        name: 'Madina Islamic Center',
        fajr: '05:30 AM',
        zuhr: '01:30 PM',
        asr: '05:00 PM',
        magrib: '06:42 PM',
        isha: '08:15 PM',
        jumua: '01:30 PM',
      },
      {
        name: 'Noor Community Mosque',
        fajr: '05:40 AM',
        zuhr: '01:15 PM',
        asr: '05:10 PM',
        magrib: '06:41 PM',
        isha: '08:15 PM',
        jumua: '01:30 PM',
      },
      {
        name: 'Rahman Mosque & Academy',
        fajr: '05:50 AM',
        zuhr: '01:30 PM',
        asr: '05:15 PM',
        magrib: '06:43 PM',
        isha: '08:30 PM',
        jumua: '01:45 PM',
      },
    ];

    for (const item of initialMasjids) {
      await addMasjid(item);
    }
    return true;
  } catch (err) {
    console.warn('Could not seed initial masjids (may require admin auth):', err);
    return false;
  }
}
